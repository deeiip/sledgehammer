var express = require('express');
var router = express.Router();
router.route('/room/:hotel_id/:date_start/:date_end').get(function(req, res) {
	
});