var express = require('express');
var router = express.Router();
router.route('/hotels/:city_code/:date_start/:date_end').get(function(req, res) {
	
});

router.route('/movies').post(function(req, res) {
  // create a new hotel. Will be used by admin
});